# Electricity Consumption Prediction Using Deep Learning

A beginner-friendly time-series forecasting project using **Simple RNN, LSTM and GRU** with a Streamlit web interface.

## 1. What this project does

- Loads the UCI Individual Household Electric Power Consumption dataset.
- Converts minute-level measurements into hourly average consumption.
- Trains a recurrent neural network to predict the next hour from a lookback window.
- Evaluates the model using MAE, RMSE and R².
- Forecasts the next 1–48 hours and allows CSV export.
- Plots historical consumption and actual-vs-predicted values.

**Target variable:** `Global_active_power`, measured in kilowatts (kW).

## 2. Requirements

- Python 3.10 or 3.11 recommended.
- Internet connection for the first automatic UCI dataset download (or download/upload the dataset manually).
- 4 GB RAM minimum; 8 GB recommended.
- No GPU is required for the default settings.

## 3. Installation on macOS

Open Terminal and move into the extracted project folder. For example:

```bash
cd ~/Downloads/electricity_consumption_prediction
```

Create a virtual environment:

```bash
python3 -m venv .venv
source .venv/bin/activate
```

Upgrade pip and install dependencies:

```bash
python -m pip install --upgrade pip
pip install -r requirements.txt
```

Start the web application:

```bash
streamlit run app.py
```

The app normally opens at:

```text
http://localhost:8501
```

To stop the app, press `Control + C` in Terminal.

## 4. Installation on Windows

Open Command Prompt in the extracted folder:

```bat
py -3.11 -m venv .venv
.venv\Scripts\activate
python -m pip install --upgrade pip
pip install -r requirements.txt
streamlit run app.py
```

## 5. Dataset

The app automatically downloads the public UCI dataset on first launch:

- Name: Individual Household Electric Power Consumption
- Source: https://archive.ics.uci.edu/dataset/235/individual+household+electric+power+consumption
- Original file: `household_power_consumption.txt`
- Separator: semicolon (`;`)
- Missing values: `?`

If automatic download is blocked, download the dataset ZIP from the UCI page, extract it, and upload `household_power_consumption.txt` using the app's uploader.

For a custom CSV, include a `Global_active_power` column and either:
- `Date` and `Time` columns, or
- a `datetime`, `timestamp`, or `date_time` column.

## 6. How to use the application

1. Launch the app with `streamlit run app.py`.
2. Wait for the dataset to load, or upload your own file.
3. Select LSTM, GRU or Simple RNN in the sidebar.
4. Choose the lookback window, epochs and batch size.
5. Click **Train model**.
6. Review MAE, RMSE, R² and the actual-vs-predicted chart.
7. Choose the forecast horizon and click **Predict next ... hours**.
8. Download the forecast CSV if required.

## 7. Project structure

```text
electricity_consumption_prediction/
├── app.py
├── requirements.txt
├── README.md
├── src/
│   ├── __init__.py
│   ├── data_utils.py
│   └── model_utils.py
├── data/       # downloaded dataset is stored here
└── models/     # reserved for saved model files
```

## 8. Model explanation

- **Simple RNN:** A recurrent neural network that processes the hourly sequence one time step at a time.
- **LSTM:** Uses input, forget and output gates to learn longer-term dependencies and reduce vanishing-gradient problems.
- **GRU:** A gated recurrent architecture similar to LSTM, typically with fewer gates and parameters.

All models receive input shaped as `(samples, lookback_hours, 1)` and predict one scaled consumption value.

## 9. Evaluation metrics

- **MAE:** Mean absolute prediction error; lower is better.
- **RMSE:** Root mean squared error; penalizes larger errors more strongly.
- **R²:** Coefficient of determination; closer to 1 generally indicates better fit.

Use a chronological train/test split (first 80% for training, final 20% for testing) to avoid leaking future observations into training.

## 10. Important academic notes

- The application resamples minute-level data to hourly means to keep training practical.
- The forecast is recursive: each predicted hour is fed back to predict the following hour. Error can accumulate over longer horizons.
- Results depend on the selected lookback window, epochs, random initialization and dataset.
- The synthetic fallback is only for checking that the UI works. Use the UCI dataset for your actual experiment and report.
- This is an educational forecasting prototype, not a production energy-management system.

## 11. Troubleshooting

**`python3: command not found`**
Install Python 3 from https://www.python.org/downloads/ and reopen Terminal.

**TensorFlow installation error**
Use Python 3.10 or 3.11 in a fresh virtual environment, then reinstall requirements. TensorFlow compatibility varies by OS and CPU architecture.

**Port 8501 is already in use**
Run:

```bash
streamlit run app.py --server.port 8502
```

**Dataset download fails**
Download and extract the UCI dataset manually, then upload the `.txt` file in the app.

**App says there are too few observations**
Ensure the uploaded dataset has at least 100 hourly observations and valid date/time and `Global_active_power` columns.
