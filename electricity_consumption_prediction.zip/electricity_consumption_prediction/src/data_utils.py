from io import BytesIO
from pathlib import Path
import zipfile
import urllib.request
import pandas as pd
import numpy as np

DATA_DIR = Path(__file__).resolve().parents[1] / "data"
DATA_DIR.mkdir(exist_ok=True)
UCI_URL = "https://archive.ics.uci.edu/static/public/235/individual+household+electric+power+consumption.zip"

def load_dataset(upload_bytes=None, filename=None):
    """Load the UCI semicolon-delimited text file or a user-uploaded CSV/TXT."""
    if upload_bytes is not None:
        data = BytesIO(upload_bytes)
        if filename and filename.lower().endswith(".csv"):
            df = pd.read_csv(data)
        else:
            df = pd.read_csv(data, sep=";", low_memory=False, na_values=["?"])
    else:
        local_txt = DATA_DIR / "household_power_consumption.txt"
        local_zip = DATA_DIR / "household_power_consumption.zip"
        if not local_txt.exists():
            if not local_zip.exists():
                try:
                    urllib.request.urlretrieve(UCI_URL, local_zip)
                except Exception as exc:
                    raise RuntimeError(
                        "Automatic download failed. Download the UCI Individual Household Electric Power Consumption "
                        "ZIP file and upload household_power_consumption.txt in the app."
                    ) from exc
            with zipfile.ZipFile(local_zip) as zf:
                candidates = [n for n in zf.namelist() if n.lower().endswith(".txt")]
                if not candidates:
                    raise RuntimeError("No .txt dataset found inside downloaded ZIP.")
                with zf.open(candidates[0]) as src, open(local_txt, "wb") as dst:
                    dst.write(src.read())
        df = pd.read_csv(local_txt, sep=";", low_memory=False, na_values=["?"])

    # Normalize common column names and parse timestamps.
    df.columns = [str(c).strip() for c in df.columns]
    if "Global_active_power" not in df.columns:
        # Support CSV files with a timestamp/date column and a consumption column.
        power_candidates = [c for c in df.columns if "global_active_power" in c.lower() or "active_power" in c.lower()]
        if not power_candidates:
            raise ValueError("Dataset must contain a Global_active_power column.")
        df = df.rename(columns={power_candidates[0]: "Global_active_power"})

    if "Date" in df.columns and "Time" in df.columns:
        dt = pd.to_datetime(df["Date"].astype(str) + " " + df["Time"].astype(str),
                            dayfirst=True, errors="coerce")
    else:
        date_col = next((c for c in df.columns if c.lower() in ("datetime", "timestamp", "date_time")), None)
        if date_col:
            dt = pd.to_datetime(df[date_col], errors="coerce")
        elif isinstance(df.index, pd.DatetimeIndex):
            dt = df.index
        else:
            raise ValueError("Dataset must contain Date and Time columns or a datetime/timestamp column.")

    power = pd.to_numeric(df["Global_active_power"], errors="coerce")
    out = pd.DataFrame({"datetime": dt, "power": power}).dropna()
    out = out.sort_values("datetime").drop_duplicates("datetime").set_index("datetime")
    return out

def prepare_series(df):
    """Convert minute-level readings to hourly mean kW and fill small gaps."""
    s = df["power"].astype(float).sort_index()
    # UCI Global_active_power is measured in kilowatts.
    hourly = s.resample("h").mean()
    hourly = hourly.interpolate(method="time", limit=3).ffill().bfill()
    hourly = hourly.replace([np.inf, -np.inf], np.nan).dropna()
    hourly.name = "Global_active_power"
    return hourly
