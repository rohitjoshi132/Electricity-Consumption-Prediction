import numpy as np
from sklearn.preprocessing import MinMaxScaler
from tensorflow.keras import Sequential
from tensorflow.keras.layers import SimpleRNN, LSTM, GRU, Dense, Dropout
from tensorflow.keras.callbacks import EarlyStopping

def create_sequences(values, lookback):
    x, y = [], []
    for i in range(lookback, len(values)):
        x.append(values[i-lookback:i, 0])
        y.append(values[i, 0])
    return np.asarray(x, dtype=np.float32).reshape(-1, lookback, 1), np.asarray(y, dtype=np.float32)

def build_model(model_name, lookback):
    layer_map = {
        "LSTM": LSTM,
        "GRU": GRU,
        "Simple RNN": SimpleRNN
    }
    recurrent_layer = layer_map[model_name]
    model = Sequential([
        recurrent_layer(64, input_shape=(lookback, 1), return_sequences=False),
        Dropout(0.2),
        Dense(32, activation="relu"),
        Dense(1)
    ])
    model.compile(optimizer="adam", loss="mse", metrics=["mae"])
    return model

def train_model(series, model_name="LSTM", lookback=24, epochs=15, batch_size=32):
    values = series.values.astype("float32").reshape(-1, 1)
    split = int(len(values) * 0.8)
    if split <= lookback or len(values) - split < 10:
        raise ValueError("Not enough data. Use a longer time series or a smaller lookback window.")
    scaler = MinMaxScaler()
    scaler.fit(values[:split])
    scaled = scaler.transform(values)
    x, y = create_sequences(scaled, lookback)
    # Target timestamp i belongs to training if i < split.
    target_indices = np.arange(lookback, len(scaled))
    train_mask = target_indices < split
    test_mask = target_indices >= split
    x_train, y_train = x[train_mask], y[train_mask]
    x_test, y_test = x[test_mask], y[test_mask]
    model = build_model(model_name, lookback)
    early_stop = EarlyStopping(monitor="val_loss", patience=4, restore_best_weights=True)
    model.fit(x_train, y_train, validation_split=0.1, epochs=epochs,
              batch_size=batch_size, callbacks=[early_stop], verbose=0, shuffle=False)
    return model, scaler, x_test, y_test, None, split

def evaluate_model(model, scaler, test_x, test_y):
    pred_scaled = model.predict(test_x, verbose=0)
    actual = scaler.inverse_transform(test_y.reshape(-1, 1)).ravel()
    predicted = scaler.inverse_transform(pred_scaled).ravel()
    return actual, predicted

def make_forecast(model, scaler, series, lookback, horizon):
    scaled = scaler.transform(series.values.reshape(-1, 1))
    window = scaled[-lookback:].reshape(1, lookback, 1)
    preds = []
    for _ in range(horizon):
        next_scaled = float(model.predict(window, verbose=0)[0, 0])
        preds.append(next_scaled)
        window = np.concatenate([window[:, 1:, :], np.array(next_scaled, dtype=np.float32).reshape(1, 1, 1)], axis=1)
    return scaler.inverse_transform(np.array(preds).reshape(-1, 1)).ravel()
