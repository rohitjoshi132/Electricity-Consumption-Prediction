import streamlit as st
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from pathlib import Path
from src.data_utils import load_dataset, prepare_series
from src.model_utils import train_model, make_forecast, evaluate_model

st.set_page_config(page_title="Electricity Consumption Predictor", page_icon="⚡", layout="wide")
st.title("⚡ Electricity Consumption Prediction")
st.caption("Deep learning time-series forecasting with Simple RNN, LSTM and GRU")

with st.sidebar:
    st.header("Project settings")
    model_name = st.selectbox("Deep learning model", ["LSTM", "GRU", "Simple RNN"])
    lookback = st.slider("Lookback window (hours)", 12, 168, 24, step=12)
    epochs = st.slider("Training epochs", 5, 50, 15)
    batch_size = st.selectbox("Batch size", [16, 32, 64], index=1)
    forecast_hours = st.slider("Forecast horizon (hours)", 1, 48, 24)
    st.markdown("---")
    st.caption("Dataset: UCI Individual Household Electric Power Consumption")

st.subheader("1. Load electricity dataset")
uploaded = st.file_uploader("Upload household_power_consumption.txt or CSV (optional)", type=["txt", "csv"])
use_sample = st.checkbox("Use generated sample data if no dataset is available", value=True)

@st.cache_data(show_spinner=False)
def get_data(upload_bytes, upload_name):
    if upload_bytes is not None:
        return load_dataset(upload_bytes=upload_bytes, filename=upload_name)
    return load_dataset()

try:
    with st.spinner("Loading dataset..."):
        raw = get_data(uploaded.getvalue() if uploaded else None, uploaded.name if uploaded else None)
        series = prepare_series(raw)
except Exception as e:
    st.warning(f"Could not load the original dataset: {e}")
    if not use_sample:
        st.info("Upload the UCI dataset or enable generated sample data.")
        st.stop()
    idx = pd.date_range("2024-01-01", periods=24*90, freq="h")
    rng = np.random.default_rng(42)
    daily = 0.35 * np.sin(2*np.pi*np.arange(len(idx))/24)
    weekly = 0.12 * np.sin(2*np.pi*np.arange(len(idx))/(24*7))
    values = np.maximum(0.4, 1.4 + daily + weekly + rng.normal(0, 0.12, len(idx)))
    series = pd.Series(values, index=idx, name="Global_active_power")
    st.info("Using reproducible synthetic hourly data for demonstration. Train with the UCI dataset for the actual project.")

if series.empty or len(series) < 100:
    st.error("The dataset has too few valid observations. Please provide at least 100 hourly observations.")
    st.stop()

c1, c2, c3 = st.columns(3)
c1.metric("Hourly observations", f"{len(series):,}")
c2.metric("Average consumption", f"{series.mean():.3f} kW")
c3.metric("Peak consumption", f"{series.max():.3f} kW")

st.subheader("2. Explore consumption")
fig, ax = plt.subplots(figsize=(12, 3.5))
ax.plot(series.index, series.values, linewidth=0.8)
ax.set_ylabel("Global active power (kW)")
ax.set_xlabel("Date")
ax.grid(alpha=0.25)
st.pyplot(fig)
plt.close(fig)

st.subheader("3. Train deep learning model")
st.write(f"Selected architecture: **{model_name}**. The model uses the previous **{lookback} hours** to predict the next hour.")
if st.button("Train model", type="primary", use_container_width=True):
    try:
        with st.spinner(f"Training {model_name} model. This may take a few minutes..."):
            model, scaler, test_x, test_y, history, split_index = train_model(
                series, model_name, lookback, epochs, batch_size
            )
            st.session_state["trained"] = {
                "model": model, "scaler": scaler, "test_x": test_x, "test_y": test_y,
                "history": history, "split_index": split_index, "series": series,
                "lookback": lookback, "model_name": model_name
            }
        st.success(f"{model_name} model trained successfully.")
    except Exception as e:
        st.exception(e)

if "trained" in st.session_state:
    trained = st.session_state["trained"]
    if trained["model_name"] != model_name or trained["lookback"] != lookback:
        st.info("Settings have changed. Train the model again to apply them.")
    model = trained["model"]
    scaler = trained["scaler"]
    test_x, test_y = trained["test_x"], trained["test_y"]
    actual, predicted = evaluate_model(model, scaler, test_x, test_y)
    mae = float(np.mean(np.abs(actual - predicted)))
    rmse = float(np.sqrt(np.mean((actual - predicted)**2)))
    denom = np.sum((actual - np.mean(actual))**2)
    r2 = float(1 - np.sum((actual-predicted)**2)/denom) if denom else float("nan")
    st.subheader("4. Model evaluation")
    a, b, c = st.columns(3)
    a.metric("MAE", f"{mae:.4f} kW")
    b.metric("RMSE", f"{rmse:.4f} kW")
    c.metric("R² score", f"{r2:.4f}")
    fig, ax = plt.subplots(figsize=(12, 4))
    n = min(300, len(actual))
    ax.plot(actual[-n:], label="Actual", linewidth=1.2)
    ax.plot(predicted[-n:], label="Predicted", linewidth=1.2)
    ax.set_title("Actual vs predicted electricity consumption (test set)")
    ax.set_ylabel("Global active power (kW)")
    ax.legend()
    ax.grid(alpha=0.25)
    st.pyplot(fig)
    plt.close(fig)

    st.subheader("5. Forecast future consumption")
    if st.button(f"Predict next {forecast_hours} hours", use_container_width=True):
        forecast = make_forecast(model, scaler, trained["series"], trained["lookback"], forecast_hours)
        future_idx = pd.date_range(trained["series"].index[-1] + pd.Timedelta(hours=1),
                                   periods=forecast_hours, freq="h")
        forecast_df = pd.DataFrame({"Forecast (kW)": forecast}, index=future_idx)
        st.session_state["forecast_df"] = forecast_df
    if "forecast_df" in st.session_state:
        forecast_df = st.session_state["forecast_df"]
        st.dataframe(forecast_df, use_container_width=True)
        fig, ax = plt.subplots(figsize=(12, 3.5))
        tail = trained["series"].tail(48)
        ax.plot(tail.index, tail.values, label="Recent actual", marker=".")
        ax.plot(forecast_df.index, forecast_df["Forecast (kW)"], label="Forecast", marker="o")
        ax.set_ylabel("Global active power (kW)")
        ax.legend()
        ax.grid(alpha=0.25)
        st.pyplot(fig)
        plt.close(fig)
        st.download_button("Download forecast CSV", forecast_df.to_csv().encode("utf-8"),
                           file_name="electricity_forecast.csv", mime="text/csv")

st.markdown("---")
st.caption("Academic demonstration only. Forecasts are estimates and should not be used for grid-control or safety-critical decisions.")
